package net.ent.etrs.kl16repaspatientgouin.model.entities.references;

public enum TypeRepas {
    PETIT_DEJEUNER,
    DEJEUNER,
    DINER
}
